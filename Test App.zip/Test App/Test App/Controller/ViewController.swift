//
//  ViewController.swift
//  Test App
//
//  Created by Mubeen Asif on 23/01/2022.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var lastSyncLbl: UILabel!
    
    @IBOutlet weak var totalPriceLbl: UILabel!
    
    var totalPrice = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        registerXib()
        getData()
        NotificationCenter.default.addObserver(self, selector: #selector(self.methodOfReceivedNotification(notification:)), name: Notification.Name("InternetConnected"), object: nil)

    }
}
extension ViewController{
    
    // get data from api
    func getData(){
        Service.shareInstance.getAllMovieData { (products, error) in
            if(error==nil){
                // saving data into db
                for obj in products!{
                    DBManager.shared.addProductToDB(product: obj)
                }
                // Save last sync time
                self.saveLastSyncTime()
                
                // Setup UI states
                self.setupUI()
            }
            else{
                // setup UI states
                self.setupUI()
            }
        }
        
    }
    
    // Register Xibs
    func registerXib(){
        tableView.register(UINib(nibName: "ProductsTableViewCell", bundle: nil), forCellReuseIdentifier: "ProductsTableViewCell")
    }
    
    // Notification called when internet is available
    @objc func methodOfReceivedNotification(notification: Notification) {
        getData()
    }
    
    // Load products from core data
    func loadProducts(){
        DBManager.shared.fetchProductsFromDB { message in
            if message == "Success"{
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
            }
        }
    }
    
    // Method for setup UI
    func setupUI(){
        DispatchQueue.main.async {
            self.lastSyncLbl.text = self.getLastSyncTime()
            self.totalPriceLbl.text = "Total Price: $ \(self.totalPrice.rounded())"
            self.loadProducts()
        }
    }
    

}
extension ViewController: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return DBManager.shared.dataArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ProductsTableViewCell") as! ProductsTableViewCell
        
        let backgroundView = UIView()
        backgroundView.backgroundColor = UIColor.clear
        cell.selectedBackgroundView = backgroundView
        let dataModel = DBManager.shared.dataArray[indexPath.row]
        cell.titleLabel.text = dataModel.title
        cell.priceLbl.text = "Price: $ \(dataModel.price)"
        cell.buyTapped = {
            self.totalPrice = self.totalPrice + dataModel.price
            self.totalPriceLbl.text = "Total Price: $ \(self.totalPrice.rounded())"
        }
        return cell
    }
    
    
    // Get last sync Time
    func getLastSyncTime() -> String{
        return "Last Sync at: \n \(UserDefaults.standard.value(forKey: "lastSync") ?? Date())"
    }
    
    // Get formatted time
    public func getFormattedTime() -> String{
        // Save data dfetching time in userdefaults
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "h:mm a MM/dd/yyyy"
        dateFormatter.timeZone = .current
        return dateFormatter.string(from:Date())
        
    }
    
    // Save Last sync Time
    func saveLastSyncTime(){
        UserDefaults.standard.setValue(self.getFormattedTime(), forKey: "lastSync")
    }
    
    
}
