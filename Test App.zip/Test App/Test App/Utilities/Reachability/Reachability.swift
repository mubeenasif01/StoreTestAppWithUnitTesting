//
//  Reachability.swift
//  Test App
//
//  Created by Mubeen Asif on 24/01/2022.
//

import Foundation
import Network

class Reachability {
    static let shared = Reachability()
    
    let monitorForWifi = NWPathMonitor(requiredInterfaceType: .wifi)
    let monitorForCellular = NWPathMonitor(requiredInterfaceType: .cellular)
    private var wifiStatus: NWPath.Status = .requiresConnection
    private var cellularStatus: NWPath.Status = .requiresConnection
    var isReachable: Bool { wifiStatus == .satisfied || isReachableOnCellular }
    var isReachableOnCellular: Bool { cellularStatus == .satisfied }
    
    func startMonitoring() {
        monitorForWifi.pathUpdateHandler = { [weak self] path in
            self?.wifiStatus = path.status
            
            if path.status == .satisfied {
                // post connected notification
                print("Wifi is connected!")
                NotificationCenter.default.post(name: Notification.Name("InternetConnected"), object: nil)
            } else {
                // post disconnected notification
                print("No wifi connection.")
            }
        }
        monitorForCellular.pathUpdateHandler = { [weak self] path in
            self?.cellularStatus = path.status
            
            if path.status == .satisfied {
                // post connected notification
                print("Cellular connection is connected!")
                NotificationCenter.default.post(name: Notification.Name("InternetConnected"), object: nil)
            } else {
                // post disconnected notification
                print("No cellular connection.")
            }
        }
        
        let queue = DispatchQueue(label: "NetworkMonitor")
        monitorForCellular.start(queue: queue)
        monitorForWifi.start(queue: queue)
    }
    
    func stopMonitoring() {
        monitorForWifi.cancel()
        monitorForCellular.cancel()
    }
    
    class func isConnectedToNetwork() -> Bool {
        return shared.isReachable
    }
}
