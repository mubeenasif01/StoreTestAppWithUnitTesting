//
//  ProductsTableViewCell.swift
//  Test App
//
//  Created by Mubeen Asif on 23/01/2022.
//

import UIKit

class ProductsTableViewCell: UITableViewCell {

    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var priceLbl: UILabel!
    var buyTapped : (() -> Void)?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @IBAction func buyBtn(_ sender: Any) {
        self.buyTapped!()
    }
    
    
}
