//
//  DBManager.swift
//  Test App
//
//  Created by Mubeen Asif on 23/01/2022.
//

import Foundation
import CoreData


class DBManager {
    
    static let shared = DBManager()

    var dataArray = [Product]()
    
    //MARK:- Custom
    func fetchProductsFromDB(completionHandler: @escaping (String) -> Void) {
        let moc = CoreDataStack.shared.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Product")
        do {
            let result = try moc.fetch(fetchRequest)
            dataArray.removeAll()
            if let objData: [Product] = result as? [Product] {
                for item in objData {
                    dataArray.append(item)
                }
                completionHandler("Success")
            } else {
                debugPrint("Error in fetching data")
                completionHandler("Failed")
            }
        } catch {
            debugPrint("Error")
            completionHandler("Failed")
        }
    }
        
    // Get Exisiting Products
     func getExistinProduct(value: Int) -> Bool {
        let context = CoreDataStack.shared.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Product")
        fetchRequest.predicate = NSPredicate(format: "id == %i", value)
        var results: [NSManagedObject] = []
        do {
            results = try context.fetch(fetchRequest)
            if results.count > 0 {
                return true
            }
        }
        catch {
            debugPrint("error executing fetch request: \(error)")
        }
        return false
    }
    
    // Delete All Products
    func deleteAllData() {
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Product")
        fetchRequest.returnsObjectsAsFaults = false
        do {
            let results = try CoreDataStack.shared.persistentContainer.viewContext.fetch(fetchRequest)
            for object in results {
                guard let objectData = object as? NSManagedObject else {continue}
                CoreDataStack.shared.persistentContainer.viewContext.delete(objectData)
                NotificationCenter.default.post(name: NSNotification.Name("deleted"), object: nil)
            }
        } catch let error {
            print("Detele all data in error :", error)
        }
    }
    
    
    // Add Product to DataBase
    func addProductToDB(product : ProductModel?) {
        guard let product = product else {
            return
        }
        
        if !self.getExistinProduct(value: product.id ?? 0) {
            let moc = CoreDataStack.shared.persistentContainer.viewContext
            let productObj =  Product(context: moc)
            productObj.category = product.category
            productObj.title = product.title
            productObj.id = Int32(product.id ?? 0)
            productObj.price = product.price ?? 0.0
        }
        
        
        CoreDataStack.shared.saveContext()

    }
}
