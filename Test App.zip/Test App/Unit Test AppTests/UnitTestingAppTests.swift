//
//  UnitTestingAppTests.swift
//  Unit Test AppTests
//
//  Created by Mubeen Asif on 08/02/2022.
//

import XCTest
@testable import Test_App

class UnitTestingAppTests: XCTestCase {
    
    // Testing get exsisting products
    func testGetExsistingProduct(){
        // given
        let db = DBManager.shared
        // when
        // Any temprory id of product
        let result = db.getExistinProduct(value: 0)
        // then
        XCTAssertFalse(result, "Does not exsist")
        
    }
    
    // fetch products
    func testFetchProduct(){
        // given
        let db = DBManager.shared
        // when
        // fetch products
        db.fetchProductsFromDB() { msg in
            if msg == "Success"{
                XCTAssertNotNil(db.dataArray)
            }else if msg == "Error"{
                XCTAssertNil(db.dataArray)
            }
        }
    }
    
    // last sync time exsit
    func testLastSyncExsist(){
        //given
        let time = UserDefaults.standard.value(forKey: "lastSync")
        // then
        XCTAssertNotNil(time)
    }
    
}
